OpenRAIL-AS license

Copyright (c) 2025 Henry Ruhs
